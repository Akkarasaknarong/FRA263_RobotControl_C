/*
 * datatype.h
 *
 *  Created on: May 30, 2026
 *      Author: Akkarasaknarong
 */

#ifndef INC_DATATYPE_H_
#define INC_DATATYPE_H_

#include "stm32g4xx_hal.h"
#include <arm_math.h>
#include <stdint.h>
#include <string.h>
#include "main.h"

// --- Refference ---
extern float Timer;

typedef struct {
	float ref_q ;
	float ref_qd ;
	float ref_qdd ;

	float ref_q_deg;
	float ref_q_index;
} refTarget_t;

// --- Current ---
typedef struct {
	float q ;
	float qd ;
	float q_deg ;
} QEIstruct_t;

// --- Steadystate Error ---
typedef struct {
	float q_ss ;
	float qd_ss ;
} SSErrorstruct_t;

// --- Kalman Estimate ---
typedef struct {
	float q_est ;
	float qd_est ;
	float load_est ;
	float i_est ;
} KALMANstruct_t;

// --- PID Parameter ---
typedef struct {
	float kp_pos;
	float kd_pos ;
	float ki_pos ;
	float kp_vel;
	float kd_vel ;
	float ki_vel ;
} PIDParam_t;

// --- Gripper State ---
typedef struct {
	int GP_Up;
	int GP_Down ;
	int GP_Close ;
	int GP_Open;
}GripperParam_t;

// --- Base system interface ---
typedef union {
    uint16_t U16;
    uint8_t  U8[2];
} u16u8_t;


typedef struct {
	QEIstruct_t     *QEI;
	refTarget_t     *REF;
} Robot_t;

static inline float IndexToDegree(int index) {
    return (float)index * 5.0f;
}

static inline int DegreeToIndex(float degree) {
    return (int)roundf(degree / 5.0f);
}

static inline float IndexToRadian(int index) {
    return (float)index * (PI / 36.0f);
}

static inline int RadianToIndex(float radian) {
    return (int)roundf(radian * (36.0f / PI));
}

static inline float DegreeToRadian(float degree) {
    return degree * (PI / 180.0f);
}

static inline float RadianToDegree(float radian) {
    return radian * (180.0f / PI);
}

#endif /* INC_DATATYPE_H_ */
