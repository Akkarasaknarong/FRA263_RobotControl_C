/*
 * User_Interface.c
 *
 *  Created on: May 31, 2026
 *      Author: Akkarasaknarong
 */

#include "User_Interface.h"

Cabinet_State_t Cabinet_State = {0};
uint32_t Local_Cabinet_Timer = 0;
Robot_Ready_t Robot_Ready = READY ;
wait_Reset_t FLAG_Wait_reset = HAVE_RESET;

void User_Interface_Start(){
	Cabinet_State.emer_button= HAL_GPIO_ReadPin(E_STOP_GPIO_Port, E_STOP_Pin);
	Cabinet_State.reset_button= HAL_GPIO_ReadPin(BUTTON_RESET_GPIO_Port, BUTTON_RESET_Pin);

	if (Cabinet_State.emer_button == 0){
		Robot_Ready = NOT_READY;
		FLAG_Wait_reset = DON_HAVE_RESET;
	}
	if (Cabinet_State.emer_button == 1){
		Robot_Ready = READY;
	}
	if (Cabinet_State.reset_button == 0){
		FLAG_Wait_reset = HAVE_RESET;
	}

	// Not Ready
	if (Robot_Ready == NOT_READY && FLAG_Wait_reset == HAVE_RESET){
		Cabinet_State.prox_state = 0 ;
		Cabinet_State.rotary_sw = 0 ;
		HAL_GPIO_WritePin(RELAY_MODE_GPIO_Port, RELAY_MODE_Pin, 0);
		HAL_GPIO_WritePin(RELAY_READY_GPIO_Port, RELAY_READY_Pin, 0);
	}
	else if (Robot_Ready == NOT_READY && FLAG_Wait_reset == DON_HAVE_RESET){
		Cabinet_State.prox_state = 0 ;
		Cabinet_State.rotary_sw = 0 ;
		HAL_GPIO_WritePin(RELAY_MODE_GPIO_Port, RELAY_MODE_Pin, 0);
		HAL_GPIO_WritePin(RELAY_READY_GPIO_Port, RELAY_READY_Pin, 0);
	// Ready
	} else if (Robot_Ready == READY && FLAG_Wait_reset == HAVE_RESET){
		Cabinet_State.rotary_sw = HAL_GPIO_ReadPin(MODE_SELECTOR_GPIO_Port,MODE_SELECTOR_Pin);
		Cabinet_State.prox_state = HAL_GPIO_ReadPin(PROX_GPIO_Port, PROX_Pin);

		if (Cabinet_State.rotary_sw == 0) {
			HAL_GPIO_WritePin(RELAY_MODE_GPIO_Port, RELAY_MODE_Pin, 1);
		} else {
			HAL_GPIO_WritePin(RELAY_MODE_GPIO_Port, RELAY_MODE_Pin, 0);
		}
		if (Cabinet_State.emer_button == 0) {
			HAL_GPIO_WritePin(RELAY_READY_GPIO_Port, RELAY_READY_Pin, 0);
		} else {
			HAL_GPIO_WritePin(RELAY_READY_GPIO_Port, RELAY_READY_Pin, 1);
		}
	}








	// Monitor
	if (Cabinet_State.emer_button == 0){
		HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, 1);
	}
	if (Cabinet_State.emer_button == 1){
			HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, 0);
		}
}




