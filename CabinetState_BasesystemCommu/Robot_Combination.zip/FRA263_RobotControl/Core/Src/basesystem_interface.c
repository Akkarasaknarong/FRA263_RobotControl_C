/*
 * basesystem_interface.c
 *
 *  Created on: May 30, 2026
 *      Author: Akkarasaknarong
 */

#include "basesystem_interface.h"

Basesystem_t Basesystem_Data = {0};
static u16u8_t* local_reg = {0};

void Manual_Mode(void){
	Basesystem_Data._Manual.Gripper_pin_state = local_reg[2].U16;
	Basesystem_Data._Manual.Gripper_command = local_reg[3].U16;

	Basesystem_Data._Manual.Jog_val = (int16_t)local_reg[5].U16;
}

void Auto_Mode(void){
	Basesystem_Data._Auto.Sequence[0] = local_reg[18].U16;
	Basesystem_Data._Auto.Sequence[1] = local_reg[19].U16;
	Basesystem_Data._Auto.Sequence[2] = local_reg[20].U16;
	Basesystem_Data._Auto.Sequence[3] = local_reg[21].U16;
	Basesystem_Data._Auto.Sequence[4] = local_reg[22].U16;
	Basesystem_Data._Auto.Sequence[5] = local_reg[23].U16;
	Basesystem_Data._Auto.Sequence[6] = local_reg[24].U16;
	Basesystem_Data._Auto.Sequence[7] = local_reg[25].U16;
	Basesystem_Data._Auto.Sequence[8] = local_reg[32].U16;
	Basesystem_Data._Auto.Sequence[9] = local_reg[33].U16;
	Basesystem_Data._Auto.N_pare = local_reg[34].U16;
	Basesystem_Data._Auto.Gripper_status = local_reg[4].U16;

	Basesystem_Data._Auto.P2P.unit = local_reg[35].U16;
	Basesystem_Data._Auto.P2P.value = local_reg[36].U16;
}

void Test_Mode(void){

}

void Basesystem_Interface_Init(){
	for (int i = 0; i < 10; ++i) {
		Basesystem_Data._Auto.Sequence[i] = 0;
	}
}

void Basesystem_Interface_Decode(u16u8_t* holding_register){
	if (Basesystem_Data.has_new_data == 1) {
		local_reg = holding_register;
		uint16_t Current_Mode = local_reg[1].U16;
		if (Current_Mode == 0) {
			Basesystem_Data.Mode = Mode_IDLE;
		} else if (Current_Mode == 2) {
			Basesystem_Data.Mode = Mode_MANUAL;
			Manual_Mode();
		} else if (Current_Mode == 4) {
			Basesystem_Data.Mode = Mode_AUTO;
			Auto_Mode();
		} else if (Current_Mode == 16) {
			Basesystem_Data.Mode = Mode_TEST;
			Test_Mode();
		}
	}
}


